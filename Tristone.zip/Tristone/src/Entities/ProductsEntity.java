/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entities;

/**
 *
 * @author Ulises
 */
public class ProductsEntity {
    
        private boolean decInt;

    /**
     * Get the value of decInt
     *
     * @return the value of decInt
     */
    public boolean getDecInt() {
        return decInt;
    }

    /**
     * Set the value of decInt
     *
     * @param decInt new value of decInt
     */
    public void setDecInt(boolean decInt) {
        this.decInt = decInt;
    }

    
    
        private String id;

    /**
     * Get the value of id
     *
     * @return the value of id
     */
    public String getId() {
        return id;
    }

    /**
     * Set the value of id
     *
     * @param id new value of id
     */
    public void setId(String id) {
        this.id = id;
    }

    private String no_sap;

    /**
     * Get the value of no_sap
     *
     * @return the value of no_sap
     */
    public String getNo_sap() {
        return no_sap;
    }

    /**
     * Set the value of no_sap
     *
     * @param no_sap new value of no_sap
     */
    public void setNo_sap(String no_sap) {
        this.no_sap = no_sap;
    }

    private String pcks;

    /**
     * Get the value of pcks
     *
     * @return the value of pcks
     */
    public String getPcks() {
        return pcks;
    }

    /**
     * Set the value of pcks
     *
     * @param pcks new value of pcks
     */
    public void setPcks(String pcks) {
        this.pcks = pcks;
    }

    private String no_part;

    /**
     * Get the value of no_part
     *
     * @return the value of no_part
     */
    public String getNo_part() {
        return no_part;
    }

    /**
     * Set the value of no_part
     *
     * @param no_part new value of no_part
     */
    public void setNo_part(String no_part) {
        this.no_part = no_part;
    }

    private String cust;

    /**
     * Get the value of cust
     *
     * @return the value of cust
     */
    public String getCust() {
        return cust;
    }

    /**
     * Set the value of cust
     *
     * @param cust new value of cust
     */
    public void setCust(String cust) {
        this.cust = cust;
    }

    private String plat;

    /**
     * Get the value of plat
     *
     * @return the value of plat
     */
    public String getPlat() {
        return plat;
    }

    /**
     * Set the value of plat
     *
     * @param plat new value of plat
     */
    public void setPlat(String plat) {
        this.plat = plat;
    }

    
}
