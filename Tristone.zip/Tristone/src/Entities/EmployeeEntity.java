/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entities;

/**
 *
 * @author Ulises
 */
public class EmployeeEntity {
    
    private String idEmployee = "";

    /**
     * Get the value of idEmployee
     *
     * @return the value of idEmployee
     */
    public String getIdEmployee() {
        return idEmployee;
    }

    /**
     * Set the value of idEmployee
     *
     * @param idEmployee new value of idEmployee
     */
    public void setIdEmployee(String idEmployee) {
        this.idEmployee = idEmployee;
    }

       private String nameEmployee;

    /**
     * Get the value of nameEmployee
     *
     * @return the value of nameEmployee
     */
    public String getNameEmployee() {
        return nameEmployee;
    }

    /**
     * Set the value of nameEmployee
     *
     * @param nameEmployee new value of nameEmployee
     */
    public void setNameEmployee(String nameEmployee) {
        this.nameEmployee = nameEmployee;
    }

        private String numEmployee;

    /**
     * Get the value of numEmployee
     *
     * @return the value of numEmployee
     */
    public String getNumEmployee() {
        return numEmployee;
    }

    /**
     * Set the value of numEmployee
     *
     * @param numEmployee new value of numEmployee
     */
    public void setNumEmployee(String numEmployee) {
        this.numEmployee = numEmployee;
    }

   

}
